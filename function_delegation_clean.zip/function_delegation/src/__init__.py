"""Function delegation project package."""
